﻿using PaymentProcessor.Models.DTO;

namespace PaymentProcessor.Gateways
{
    public interface ICheapPaymentGateway : IPaymentGateway
    {   
    }
}