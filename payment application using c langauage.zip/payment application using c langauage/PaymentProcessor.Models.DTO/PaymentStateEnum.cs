﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PaymentProcessor.Models.DTO
{
    public enum PaymentStateEnum
    {
        Pending
        , Processed
        , Failed
    }
}
